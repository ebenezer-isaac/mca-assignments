create view branch_accounts as
select `bank`.`branch`.`BCODE`         AS `bcode`,
       `bank`.`branch`.`BNAME`         AS `bname`,
       count(`bank`.`account`.`BCODE`) AS `accounts`
from (`bank`.`branch`
         join `bank`.`account` on (`bank`.`branch`.`BCODE` = `bank`.`account`.`BCODE`))
group by `bank`.`branch`.`BCODE`, `bank`.`branch`.`BNAME`;

