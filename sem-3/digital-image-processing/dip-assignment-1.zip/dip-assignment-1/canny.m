img=imread('passport.jpg')
imshow(img);
img=rgb2gray(img);
opImg=(edge(img,"Canny"));
imshow(opImg);