clc
clear all
close all
pkg load image
img1=imread('passport.jpg');
imshow(img1);
imhist(img1,1024);
op=imdivide(img1,img1);
imshow(op);
imhist(op,1024);