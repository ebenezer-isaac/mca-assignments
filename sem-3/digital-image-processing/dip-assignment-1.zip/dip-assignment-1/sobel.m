img=imread('passport.jpg')
imshow(img);
img=rgb2gray(img);
opImg=(edge(img,"sobel"));
imshow(opImg);