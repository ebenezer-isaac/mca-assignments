clc
clear all
close all
img1=imread('passport.jpg');
imshow(img1);
img =rgb2gray(img1);
imgOP= imsmooth(img,"Gaussian");
imshow(imgOP);