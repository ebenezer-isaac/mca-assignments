Original=imread('passport.jpg');
BW = rgb2gray(Original);
minf=@(x) min(x(:));
maxf=@(x)max(x(:));
min_Image=nlfilter(BW,[3 3],minf);
max_Image=nlfilter(BW,[3 3],maxf);
subplot(2,2,1), imshow(BW), title('Original');
subplot(2,2,2), imshow(min_Image), title('Min');
subplot(2,2,3), imshow(max_Image), title('Max');